void print(char* msg);
