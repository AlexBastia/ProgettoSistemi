#ifndef SCHEDULER_H
#define SCHEDULER_H

#include "../../headers/const.h"
#include "../../headers/types.h"


void Scheduler();

#endif
