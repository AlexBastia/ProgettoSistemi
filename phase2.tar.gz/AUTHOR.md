Project Authors
===============

* Alex Bastianini (alex.bastianini@studio.unibo.it)
* Giovanni Menozzi (giovanni.menozzi3@studio.unibo.it)
* Mattia Meschini (mattia.meschini@studio.unibo.it)
* Dario Venuto (dario.venuto@studio.unibo.it)
